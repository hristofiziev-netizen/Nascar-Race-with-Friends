import PicksClient from "./ui";

export default function PicksPage() {
  return <PicksClient />;
}
